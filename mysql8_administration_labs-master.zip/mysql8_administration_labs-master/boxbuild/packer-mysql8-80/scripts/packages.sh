#!/bin/sh -eux

yum install -y socat tmux vim yum-utils sysstat nc telnet

