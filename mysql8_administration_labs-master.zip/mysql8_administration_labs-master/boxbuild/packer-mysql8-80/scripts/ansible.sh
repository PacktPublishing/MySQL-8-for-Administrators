#!/bin/sh -eux

yum install -y ansible
