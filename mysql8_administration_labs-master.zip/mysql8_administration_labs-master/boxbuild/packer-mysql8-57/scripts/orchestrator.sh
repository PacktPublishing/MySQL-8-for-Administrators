#!/bin/sh -eux
curl -L -O https://github.com/github/orchestrator/releases/download/v3.0.8/orchestrator-3.0.8-1.x86_64.rpm
curl -L -O https://github.com/github/orchestrator/releases/download/v3.0.8/orchestrator-cli-3.0.8-1.x86_64.rpm
