#!/bin/sh -eux

yum install -y ansible-2.4.2.0-2.el7.noarch
